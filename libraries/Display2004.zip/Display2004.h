// Display2004.h

#ifndef _DISPLAY2004_h
#define _DISPLAY2004_h

#include "Arduino.h"
// The following lines are required by the Digole serial LCD display, connected to serial port 1.
// The Digole LCD is an object that is used by our primary 20x04 LCD object "Display2004."
#define _Digole_Serial_UART_    // To tell compiler compile the serial communication only
#include <DigoleSerial.h>

void endWithFlashingLED(int numFlashes);  // Display2004 calls endWithFlashingLED and thus needs the function prototype declared here

class Display2004
{
  public:

    Display2004(HardwareSerial * hdwrSerial, unsigned long baud);  // Constructor declaration, note this does not specify a return type
    void init();
    void send(const char nextLine[]);

  protected:

  private:

    const byte LCD_WIDTH = 20;    // Number of chars wide on the 20x04 LCD displays on the control panel
    DigoleSerialDisp * _display;  // A member field in the Display2004 class that holds a pointer to a Digole object, per Tim.

};

// extern Display2004 Display2004();  // What does this do???  Visual Studio added it as part of the default "new class" setup

#endif

